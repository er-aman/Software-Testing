import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem2ClassTest {
	
	Problem2Class prob2;
	
	@Before
	public void setUp () {
		prob2 = new Problem2Class();
	}
	
	@Test
	@FileParameters("src/HW_5.1_Problem2.csv")	
	public void test(int TestCaseNumber, int month, int day, int year, int result,String bpnumber,String mcdc,String comments) {
		assertEquals(result, prob2.calcNextDay(month, day, year));
	}
}
