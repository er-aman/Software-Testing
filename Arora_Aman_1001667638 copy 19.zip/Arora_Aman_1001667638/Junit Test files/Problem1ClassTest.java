import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
import java.lang.String;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
@RunWith(JUnitParamsRunner.class)
public class Problem1ClassTest {
	private Problem1Class prob1;
	@Before
	public void setUp () {
		prob1 = new Problem1Class();
	}
	@Test
	@FileParameters("src/HW_5.1_Problem1.csv")
	public void test(int testcaseNumber,boolean selfDrive, double distance,int nearestCar,int carSpeed,boolean autoDisengage,int timer,boolean redLight,boolean yellowLight,boolean greenLight,boolean autoBrakes,String mcdc,String comments ) {
		prob1.setRedLight(!redLight);
		prob1.setYellowLight(!yellowLight);
		prob1.setGreenLight(!greenLight);
		prob1.setAutoBrakes(!autoBrakes);
		prob1.setTimer(0);
		prob1.setAutoDisengage(!autoDisengage);
		prob1.autoDisEng(selfDrive, distance, nearestCar, carSpeed);
		assertEquals(redLight,prob1.isRedLight());
		assertEquals(yellowLight,prob1.isYellowLight());
		assertEquals(greenLight,prob1.isGreenLight());
		assertEquals(autoBrakes,prob1.isAutoBrakes());
		assertEquals(timer,prob1.getTimer());
		assertEquals(autoDisengage,prob1.isAutoDisengage());
		
	}

}
