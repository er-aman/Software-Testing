public class Problem1Class {
	int timer;
	boolean autoDisengage,redLight,yellowLight,greenLight,autoBrakes;
	
	public void autoDisEng (boolean selfDrive, double distance, int nearestCar, int carSpeed) {
		timer=0;redLight=yellowLight=greenLight=autoBrakes=false;
		if (selfDrive) {
			greenLight = (distance>200.0);
			yellowLight = (distance<=200.0) && (distance>=100.0);
			redLight = (distance<100.0);
			autoBrakes = (distance<=50.0);
		} 
		autoDisengage = selfDrive && ((nearestCar<=50) || (carSpeed>65));
		timer = (selfDrive) && (nearestCar<=50) && (carSpeed>65) ? 5:10;
	}

	public boolean isRedLight() {
		return redLight;
	}

	public void setRedLight(boolean redLight) {
		this.redLight = redLight;
	}

	public boolean isYellowLight() {
		return yellowLight;
	}

	public void setYellowLight(boolean yellowLight) {
		this.yellowLight = yellowLight;
	}

	public boolean isGreenLight() {
		return greenLight;
	}

	public void setGreenLight(boolean greenLight) {
		this.greenLight = greenLight;
	}

	public boolean isAutoBrakes() {
		return autoBrakes;
	}

	public void setAutoBrakes(boolean autoBrakes) {
		this.autoBrakes = autoBrakes;
	}

	public int getTimer() {
		return timer;
	}

	public void setTimer(int timer) {
		this.timer = timer;
	}

	public boolean isAutoDisengage() {
		return autoDisengage;
	}

	public void setAutoDisengage(boolean autoDisengage) {
		this.autoDisengage = autoDisengage;
	}
}
