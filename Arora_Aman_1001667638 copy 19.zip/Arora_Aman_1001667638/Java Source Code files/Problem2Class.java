public class Problem2Class {

	public int calcNextDay (int month, int day, int year) {
		int result=0,daysIn[] = {31, 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

		if ((year%4==0) && ((year%100!=0) || (year%400==0)))
		  daysIn[1] = 29; 
		else
		  daysIn[1] = 28;

		if (month==12 && day==31)
			result=1;
		else {
			for (int i=0;i<month-1;i++)
				result+=daysIn[i];
			result+=day+1;
		}
		return result;
	}
}